//
//  MovieGridCell.swift
//  unit 1 flix
//
//  Created by Evan Weatherspoon on 2/7/21.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    @IBOutlet weak var posterView: UIImageView!
    
}
